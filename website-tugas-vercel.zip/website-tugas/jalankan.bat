@echo off
cd /d "%~dp0"
echo Website berjalan di http://localhost:8000
echo Jangan tutup jendela ini selama website digunakan.
where py >nul 2>nul
if %errorlevel%==0 (
  start http://localhost:8000
  py -m http.server 8000 --bind 0.0.0.0
) else (
  start http://localhost:8000
  python -m http.server 8000 --bind 0.0.0.0
)
pause
